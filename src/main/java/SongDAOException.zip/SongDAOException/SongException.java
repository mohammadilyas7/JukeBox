package SongDAOException;

import java.sql.SQLException;

public class SongException extends Exception
{
    public SongException(){super();}
    public SongException(String message){super(message);}

}
